
let users = JSON.parse(localStorage.getItem('users') || '{}');
let currentUser = null;
const weapons = [
  { name: "十字弓", chance: 0.1, rarity: "Exclusive" },
  { name: "噴火槍", chance: 0.1, rarity: "Exclusive" },
  { name: "外星槍", chance: 0.1, rarity: "Exclusive" },
  { name: "雷射槍", chance: 0.1, rarity: "Exclusive" },
  { name: "地雷", chance: 0.3, rarity: "Legendary" },
  { name: "冰凍光束槍", chance: 0.4, rarity: "Legendary" },
  { name: "戰斧", chance: 1, rarity: "Legendary" },
  { name: "榴彈砲", chance: 2, rarity: "Epic" },
  { name: "AK47", chance: 2, rarity: "Epic" },
  { name: "弓", chance: 5, rarity: "Epic" },
  { name: "閃光彈", chance: 5, rarity: "Epic" },
  { name: "燃燒瓶", chance: 5, rarity: "Epic" },
  { name: "烏茲衝鋒", chance: 5, rarity: "Epic" },
  { name: "閃光槍", chance: 5, rarity: "Epic" },
  { name: "手雷", chance: 10, rarity: "Basic" },
  { name: "小刀", chance: 10, rarity: "Basic" },
  { name: "槍刃", chance: 10, rarity: "Basic" },
  { name: "突擊步槍", chance: 38.9, rarity: "Basic" },
];
function showLogin() {
  document.getElementById('registerSection').style.display = 'none';
  document.getElementById('loginSection').style.display = 'block';
}
function showRegister() {
  document.getElementById('loginSection').style.display = 'none';
  document.getElementById('registerSection').style.display = 'block';
}
function login() {
  const user = document.getElementById('username').value;
  const pass = document.getElementById('password').value;
  if (users[user] && users[user].password === pass) {
    currentUser = user;
    document.getElementById('loginSection').style.display = 'none';
    document.getElementById('gameSection').style.display = 'block';
    document.getElementById('playerName').innerText = user;
    updateLeaderboard();
  } else {
    alert("Invalid credentials.");
  }
}
function register() {
  const user = document.getElementById('regUsername').value;
  const pass = document.getElementById('regPassword').value;
  if (pass.length < 8) return alert("Password must be 8+ characters");
  if (!users[user]) {
    users[user] = { password: pass, backpack: [], score: 0 };
    localStorage.setItem('users', JSON.stringify(users));
    alert("Registered! Please login.");
    showLogin();
  } else {
    alert("User exists!");
  }
}
function draw() {
  let rand = Math.random() * 100;
  let sum = 0;
  for (let weapon of weapons) {
    sum += weapon.chance;
    if (rand <= sum) {
      showResult(weapon);
      users[currentUser].backpack.push(weapon.name);
      users[currentUser].score += Math.round(1000 / weapon.chance);
      localStorage.setItem('users', JSON.stringify(users));
      updateLeaderboard();
      break;
    }
  }
}
function showResult(weapon) {
  const popup = document.getElementById('resultPopup');
  popup.innerHTML = `<h2>🎉 You got: ${weapon.name} (${weapon.rarity})</h2>`;
  popup.style.display = 'block';
  setTimeout(() => { popup.style.display = 'none'; }, 4000);
}
function showBackpack() {
  const items = users[currentUser].backpack || [];
  const popup = document.getElementById('backpack');
  popup.innerHTML = `<h3>Backpack</h3><ul>${items.map(w => `<li>${w}</li>`).join('')}</ul>`;
  popup.style.display = 'block';
  setTimeout(() => { popup.style.display = 'none'; }, 5000);
}
function updateLeaderboard() {
  const board = document.getElementById('leaderboard');
  const sorted = Object.entries(users)
    .filter(([u, d]) => !["gddplaygames", "402vip777", "Teddy0908"].includes(u))
    .sort((a, b) => b[1].score - a[1].score)
    .slice(0, 100);
  board.innerHTML = sorted.map(([u, d]) => `<li>${u}: ${d.score}</li>`).join('');
}
